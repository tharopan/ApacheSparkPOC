package com.ApacheSparkPOC;

public class DataType {
    // public static long value(int x){
    //     return 32;
    // }

    // public static long value(long x){
    //     return 64;
    // }
}