package com.ApacheSparkPOC;

public enum MLibAlgorithm {
	KMeans, //K-means
	BisectingKMeans,
	LDA,
	GMMs // Gaussian mixtures
}